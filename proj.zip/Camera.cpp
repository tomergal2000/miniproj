#include "Include.h"

State currentMode = State::INITIAL;

void drawCameraViewTriangle(const glm::vec3& position, const glm::vec3& direction, bool flag) {
    glm::vec3 right = glm::normalize(glm::cross(direction, cameraUp)) * 0.1f;
    glm::vec3 up = glm::normalize(glm::cross(right, direction)) * 0.1f;

    glDisable(GL_LIGHTING);
    if (flag) {
        glColor3f(0.824f, 0.016f, 0.176f);
    }
    else {
        glColor3f(0.373f, 0.62f, 0.627f);
    }

    glBegin(GL_TRIANGLES);
    glVertex3f(position.x, position.y, position.z);
    glVertex3f(position.x + direction.x * 0.4f + right.x, position.y + direction.y * 0.4f + right.y, position.z + direction.z * 0.4f + right.z);
    glVertex3f(position.x + direction.x * 0.4f - right.x, position.y + direction.y * 0.4f - right.y, position.z + direction.z * 0.4f - right.z);
    glEnd();
    glEnable(GL_LIGHTING);
}

void drawCameraPath() {
    if (cameraPath.size() < 2) return; // Need at least two points to draw a line

    glPushAttrib(GL_ENABLE_BIT); // Save current enable bit states
    glDisable(GL_LIGHTING); // Disable lighting to ensure the color is applied correctly

    glEnable(GL_BLEND); // Enable blending
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); // Set blend function

    glEnable(GL_LINE_SMOOTH); // Enable line smoothing
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST); // Set the line smoothing hint to the highest quality

    glColor4f(0.0f, 0.0f, 0.545f, 0.8f); // Set line color with alpha for blending
    glLineWidth(7.0f); // Set line width

    glBegin(GL_LINE_STRIP);
    for (const auto& pos : cameraPath) {
        glVertex3f(pos.x, pos.y, pos.z);
    }
    glEnd();

    glPopAttrib(); // Restore previous enable bit states
}

struct CameraState saveCameraState() {
    CameraState state = { cameraPos, cameraFront, yaw, pitch };

    // Capture the right viewport (camera view)
    int width = WIDTH / 2;
    int height = HEIGHT;
    std::vector<unsigned char> image(static_cast<size_t>(3) * static_cast<size_t>(width) * static_cast<size_t>(height));
    glReadPixels(width, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE, image.data());
    state.image = std::move(image);

    return state;
}

void loadCameraImage(GLFWwindow* window) {
    currentCameraStateIndex = (currentCameraStateIndex) % savedCameraStates.size();
    CameraState state = savedCameraStates[currentCameraStateIndex];

    std::vector<unsigned char> image = state.image;

    glDrawPixels(WIDTH / 2, HEIGHT, GL_RGB, GL_UNSIGNED_BYTE, image.data());
}

void loadNextCameraState() {
    if (!savedCameraStates.empty()) {
        // Load the next camera state
        currentCameraStateIndex = (currentCameraStateIndex) % savedCameraStates.size();
        CameraState state = savedCameraStates[currentCameraStateIndex];
        cameraPos = state.position;
        cameraFront = state.front;
        yaw = state.yaw;
        pitch = state.pitch;

        // Recalculate the camera front vector based on the loaded yaw and pitch
        glm::vec3 front;
        front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
        front.y = sin(glm::radians(pitch));
        front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
        cameraFront = glm::normalize(front);   
    }
   
}

void updateCamera() {
    const float cameraSpeed = 0.005f;
    constexpr float rotationSpeed = glm::radians(0.05f);
    bool positionChanged = false;

    if (pressedKey.w) {
        cameraPos += cameraSpeed * cameraFront;
        positionChanged = true;
    }
    if (pressedKey.s) {
        cameraPos -= cameraSpeed * cameraFront;
        positionChanged = true;
    }
    if (pressedKey.a) {
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
        positionChanged = true;
    }
    if (pressedKey.d) {
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
        positionChanged = true;
    }
    if (pressedKey.left) {
        yaw -= glm::degrees(rotationSpeed);
    }
    if (pressedKey.right) {
        yaw += glm::degrees(rotationSpeed);
    }
    if (pressedKey.up) {
        pitch += glm::degrees(rotationSpeed);
    }
    if (pressedKey.down) {
        pitch -= glm::degrees(rotationSpeed);
    }

    // Constrain the pitch to prevent flipping
    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;

    // Calculate the new camera front vector
    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);

    if (positionChanged && !pickingState) {
        cameraPath.push_back(cameraPos); // Save the new camera position
    }
}

void loadCameraWithParam(glm::vec3 calculatedPos, float calcYaw, float calcPitch) {
    cameraPos = calculatedPos;
    yaw = calcYaw;
    pitch = calcPitch;

    glm::vec3 front;
    front.x = cos(glm::radians(pitch)) * cos(glm::radians(yaw));
    front.y = sin(glm::radians(pitch));
    front.z = cos(glm::radians(pitch)) * sin(glm::radians(yaw));
    cameraFront = glm::normalize(front);

    cameraPnpSol = saveCameraState();
}




// Handle keyboard input for camera movement:




void handlePickingMode(unsigned char input) {
    if (input == '1') {
        if (savedCameraStates.size() == 0) {
            return;
        }
        pickingState = !pickingState;
        if (pickingState) {
            lastState.position = cameraPos;
            lastState.front = cameraFront;
            lastState.yaw = yaw;
            lastState.pitch = pitch;
        }
        else {
            cameraPos = lastState.position;
            cameraFront = lastState.front;
            yaw = lastState.yaw;
            pitch = lastState.pitch;

            // Recalculate the camera front vector based on the loaded yaw and pitch
            glm::vec3 front;
            front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
            front.y = sin(glm::radians(pitch));
            front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
            cameraFront = glm::normalize(front);

            currentMode = State::INITIAL;
        }
    }
    if (input == '2') { // i am in picking mode and pressed C
        chooseState = !chooseState;
        if (chooseState) {// pressed c in pick mode
            if (myClickData.numLeft == 0) {
                chooseState = !chooseState;
                return;
            }
            else if (myClickData.numLeft != myClickData.numRight) {
                chooseState = !chooseState;
                return;
            }
            else {
                lastPickingState.position = cameraPos;
                lastPickingState.front = cameraFront;
                lastPickingState.yaw = yaw;
                lastPickingState.pitch = pitch;
                std::pair<glm::vec3, glm::vec2> result = estimateCameraPose();
                glm::vec3 first = result.first;
                glm::vec2 second = result.second;
                loadCameraWithParam(first, second.x, second.y);

                // to return to picking right view pos:
                cameraPos = lastPickingState.position;
                cameraFront = lastPickingState.front;
                yaw = lastPickingState.yaw;
                pitch = lastPickingState.pitch;

            }
        }
    }
}

void handleLoadStateMode(unsigned char input) {
    if (tolower(input) == '3') {
        if (savedCameraStates.size() == 0) {
            return;
        }
        loadState = !loadState;
        if (loadState) {
            lastState.position = cameraPos;
            lastState.front = cameraFront;
            lastState.yaw = yaw;
            lastState.pitch = pitch;
            loadNextCameraState();
        }
        else {
            cameraPos = lastState.position;
            cameraFront = lastState.front;
            yaw = lastState.yaw;
            pitch = lastState.pitch;

            // Recalculate the camera front vector based on the loaded yaw and pitch
            glm::vec3 front;
            front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
            front.y = sin(glm::radians(pitch));
            front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
            cameraFront = glm::normalize(front);
            currentMode = State::INITIAL; // Exit load state mode
        }

    }

}

void keyCallback(unsigned char input, int x, int y) {
    // Handle mode selection
    if (currentMode == State::INITIAL) {
        if (tolower(input) == '1') {
            currentMode = State::SELECT;
            handlePickingMode(input);
            return;
        }
        else if (tolower(input) == '3') {
            currentMode = State::LOAD;
            handleLoadStateMode(input);
            return;
        }
    }

    // Check if a mode is active and handle mode-specific logic
    if (currentMode == State::SELECT) {
        handlePickingMode(input);
        if (!pickingState) {
            currentMode = State::INITIAL; // Exit picking mode
        }
        return;
    }
    else if (currentMode == State::LOAD) {
        handleLoadStateMode(input);
        if (!loadState) {
            currentMode = State::INITIAL; // Exit load state mode
        }
        return;
    }
    else if (tolower(input) == '4') {
        savedCameraStates.push_back(saveCameraState());
    }
}

void updatepressedKey(unsigned char input, int x, int y) {
    if (loadState || chooseState) {// we send here in order to disable movement
        keyCallback(input, x, y);
        return;
    }
    switch (tolower(input)) {
    case '1': case '4': case '3': case '2': keyCallback(input, x, y); break;
    case 'w': pressedKey.w = true; break;
    case 'a': pressedKey.a = true; break;
    case 's': pressedKey.s = true; break;
    case 'd': pressedKey.d = true; break;
    }
}

void updateKeyUp(unsigned char input, int x, int y) {
    if (loadState || chooseState) {
        return;
    }
    switch (input) {
    case '1': case '4': case '3': case '2': break;
    case 'w': case 'W': pressedKey.w = false; break;
    case 'a': case 'A': pressedKey.a = false; break;
    case 's': case 'S': pressedKey.s = false; break;
    case 'd': case 'D': pressedKey.d = false; break;
    }
}

void updateSpecialpressedKey(int input, int x, int y) {
    if (chooseState) {
        return;
    }
    if (loadState) {
        if (input == GLUT_KEY_RIGHT) {
            currentCameraStateIndex++;
            loadNextCameraState();
            return; // Early return to prevent further processing of this key event
        }
        else if (input == GLUT_KEY_LEFT) {
            currentCameraStateIndex--;
            if (currentCameraStateIndex < 0) {
                currentCameraStateIndex = (int)savedCameraStates.size() - 1;
            }
            loadNextCameraState();
            return; // Early return to prevent further processing of this key event
        }
    }
    switch (input) {
    case GLUT_KEY_LEFT: pressedKey.left = true; break;
    case GLUT_KEY_RIGHT: pressedKey.right = true; break;
    case GLUT_KEY_UP: pressedKey.up = true; break;
    case GLUT_KEY_DOWN: pressedKey.down = true; break;
    }
}

void updateSpecialKeyUp(int input, int x, int y) {
    if (loadState || chooseState) {
        return; // Early return to prevent further processing of this key event
    }
    switch (input) {
    case GLUT_KEY_LEFT: pressedKey.left = false; break;
    case GLUT_KEY_RIGHT: pressedKey.right = false; break;
    case GLUT_KEY_UP: pressedKey.up = false; break;
    case GLUT_KEY_DOWN: pressedKey.down = false; break;
    }
}