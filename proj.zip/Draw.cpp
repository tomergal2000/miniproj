#include "Include.h"

void drawCosahedron() {
    GLfloat materialAmbient[] = { 0.2f, 0.2f, 0.2f, 1.0f };
    // Set the diffuse color to cyan
    GLfloat materialDiffuse[] = { 0.0f, 1.0f, 1.0f, 1.0f };
    GLfloat materialSpecular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat materialShininess[] = { 50.0f };

    glMaterialfv(GL_FRONT, GL_AMBIENT, materialAmbient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, materialDiffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, materialSpecular);
    glMaterialfv(GL_FRONT, GL_SHININESS, materialShininess);

    glutSolidIcosahedron();
}


