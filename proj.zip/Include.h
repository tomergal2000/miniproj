#pragma once
#ifndef INCLUDE_H
#define INCLUDE_H

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <GL/glut.h>
#include <opencv2/opencv.hpp>
#include <opencv2/calib3d.hpp>
#include <vector>
#include <iostream>

// From pnp:
std::vector<cv::Point2f> convertToCvPoint2f(const std::vector<glm::vec2>& points);
std::vector<cv::Point3f> convertToCvPoint3f(const std::vector<glm::vec3>& points);
std::pair<glm::vec3, glm::vec2> estimateCameraPose();


// From camera:
void drawCameraViewTriangle(const glm::vec3& position, const glm::vec3& direction, bool flag);
void drawCameraPath();
struct CameraState saveCameraState();
void loadCameraImage(GLFWwindow* window);
void loadNextCameraState();
void updateCamera();
void loadCameraWithParam(glm::vec3 calculatedPos, float calcYaw, float calcPitch);

// From draw:
void drawCosahedron();

// From mode control:
enum class State {
    INITIAL,   // Initial state
    SELECT,   // After pressing '1'
    LOAD // After pressing '2'
};

extern State currentMode;

void updatepressedKey(unsigned char input, int x, int y);
void updateKeyUp(unsigned char input, int x, int y);
void updateSpecialpressedKey(int input, int x, int y);
void updateSpecialKeyUp(int input, int x, int y);
void keyCallback(unsigned char input, int x, int y);
std::vector<glm::vec3> generatePoints(int k);

// From object: ^��"�

// From render:
void renderLeftPickingViewport();
void renderRightPickingViewport();
void renderLeftNormalViewport();
void renderRightNormalViewport();
void renderPickingMode();
void renderNormalMode();
void drawDividerLine();
void renderScene();
glm::vec3 getClickedPoint(int x, int y);
void setupRightViewport();
void drawSpheres(const glm::vec3& threeDPoint, glm::vec3& color);

// From global variables:
// Window dimensions
extern const int WIDTH;
extern const int HEIGHT;

// Camera transformation
extern glm::vec3 cameraPos;
extern glm::vec3 cameraFront;
extern glm::vec3 cameraUp;

// Camera rotation
extern float yaw;
extern float pitch;

// Saved camera state
extern glm::vec3 savedCameraPos;
extern glm::vec3 savedCameraFront;
extern float savedYaw;
extern float savedPitch;

// Object transformation
extern glm::vec3 objectPos;
extern float objectRotationX;
extern float objectRotationY;

// Image storage
extern std::vector<unsigned char> image;

struct CameraState {
    glm::vec3 position;
    glm::vec3 front;
    float yaw;
    float pitch;
    std::vector<unsigned char> image;
};

struct PressedKey {
    bool w = false;
    bool a = false;
    bool s = false;
    bool d = false;
    bool left = false;
    bool right = false;
    bool up = false;
    bool down = false;
};

struct ClickCoords {
    double x;
    double y;
};

// Vector to store all click coordinates
extern std::vector<ClickCoords> clickCoordinates;

extern PressedKey pressedKey;

// Saved camera states
extern std::vector<CameraState> savedCameraStates;
extern int currentCameraStateIndex;
extern bool loadState;
extern bool pickingState;
extern bool chooseState;

extern std::vector<glm::vec3> cameraPath;

extern CameraState lastState;
extern CameraState lastPickingState;
extern CameraState cameraPnpSol;

// Click data structure
struct ClickData {
    std::vector<glm::vec2> leftSideClicks;
    std::vector<glm::vec3> rightSideClicks;
    int numLeft = 0;
    int numRight = 0;

    void addLeftClick(double xpos, double ypos) {
        numLeft++;
        leftSideClicks.emplace_back(xpos, ypos);
    }

    void addRightClick(const glm::vec3& clickWorldPos) {
        if (numRight >= numLeft) {
            return;
        }
        numRight++;
        rightSideClicks.push_back(clickWorldPos);
    }
};

extern ClickData myClickData;

struct Sphere {
    glm::vec3 center;
    float radius;
};

// Declare global variables
extern std::vector<Sphere> spheres;

// Color definitions
extern glm::vec3 colors[8];


#endif